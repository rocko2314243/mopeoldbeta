const game = require('./gameserver')

new game(80)
